# Oracle SQL Lab Assignments

This repository contains three assignment folders:

- `Assignment-7/Assignment-7.sql` — Oracle SQL single-row, character, number and date functions.
- `Assignment-8/Assignment-8.sql` — Set operators, constraints, aggregate functions and birthday queries.
- `Assignment-9/Assignment-9.sql` — Customer/Movie/Invoice joins and employee self-joins.

## How to run
1. Open the `.sql` file in Oracle SQL Developer.
2. Run statements in order (F5 / Run Script is convenient).
3. Assignment 7 expects `EMPLOYEE_DETAILS` to exist and contain the assignment data.
4. Assignment 9 Group B expects the Oracle HR `EMPLOYEES` table.
5. Assignment 8 has a note about the apparent duplicate Sports roll number in the supplied image; verify Anurag's roll number before running.

Run each assignment in a separate schema or drop existing tables first if you need to rerun the CREATE TABLE statements.
